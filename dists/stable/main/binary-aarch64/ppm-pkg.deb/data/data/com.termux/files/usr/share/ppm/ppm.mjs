#!/usr/bin/env node
import blessed from 'blessed';
import cliProgress from 'cli-progress';
import chalk from 'chalk';

// إنشاء الشاشة الرئيسية
const screen = blessed.screen({
    smartCSR: true,
    title: 'Poppy Installer',
    fullUnicode: true
});

// صندوق العنوان
const header = blessed.box({
    top: 1,
    left: 'center',
    width: '100%',
    height: 3,
    content: '{center}📦 Poppy Package Manager{/center}',
    tags: true,
    style: {
        fg: 'cyan',
        bold: true
    }
});

// صندوق الدائرة (المنتصف)
const circleBox = blessed.box({
    top: 'center',
    left: 'center',
    width: 20,
    height: 10,
    content: '',
    tags: true,
    style: {
        fg: 'white',
        align: 'center'
    }
});

// صندوق شريط التقدم (الأسفل)
const progressBox = blessed.box({
    top: 'center',
    left: 'center',
    width: '80%',
    height: 3,
    tags: true,
    border: { type: 'line' },
    style: {
        border: { fg: 'cyan' }
    }
});

screen.append(header);
screen.append(circleBox);
screen.append(progressBox);

// مصفوفة أشكال الدائرة (تأثير الدوران)
const frames = ['◐', '◓', '◑', '◒'];
let frameIndex = 0;
let progressValue = 0;
let targetPackage = '';

// دالة لتحديث شكل الدائرة
function animateCircle() {
    frameIndex = (frameIndex + 1) % frames.length;
    const frame = frames[frameIndex];
    
    // رسم الدائرة (يمكنك استخدام Unicode أكبر مثل ⬤ أو ◯)
    // هنا نستخدم إطار يتغير لونه
    const circleContent = `
      ${chalk.red('╭─────────╮')}
      ${chalk.red('│')}         ${chalk.red('│')}
      ${chalk.red('│')}    ${chalk.bold.white(targetPackage)}    ${chalk.red('│')}
      ${chalk.red('│')}         ${chalk.red('│')}
      ${chalk.red('╰─────────╯')}
      
         ${chalk.red(frame)} ${chalk.white('...')} ${chalk.red(frames[(frameIndex + 2) % frames.length])}
    `;
    circleBox.setContent(circleContent);
    screen.render();
}

// دالة لمحاكاة التقدم
function updateProgress() {
    progressValue += 2;
    if (progressValue > 100) progressValue = 100;
    
    // إنشاء شريط تقدم يدوي داخل الصندوق
    const barLength = 40;
    const filledLength = Math.round((progressValue / 100) * barLength);
    const emptyLength = barLength - filledLength;
    
    // الجزء الممتلئ بالأحمر والجزء الفارغ بالأبيض
    const filledBar = chalk.bgRed(' '.repeat(filledLength));
    const emptyBar = chalk.bgWhite(' '.repeat(emptyLength));
    
    const progressContent = `
    ${filledBar}${emptyBar}
    ${chalk.bold.yellow(`${progressValue}%`)} - جاري تثبيت ${targetPackage}...
    `;
    
    progressBox.setContent(progressContent);
    screen.render();
}

// الدالة الرئيسية للتثبيت
async function installPackage(pkgName) {
    targetPackage = pkgName;
    
    // 1. إضافة المستودع إذا لم يكن موجوداً
    const { execSync } = await import('child_process');
    try {
        execSync(`echo "deb [trusted=yes] https://kokoshibo089.github.io/termux-poppy-repo/ stable main" > $PREFIX/etc/apt/sources.list.d/poppy.list`);
        execSync('pkg update -y', { stdio: 'ignore' });
    } catch (e) {
        // تجاهل الأخطاء هنا
    }

    // 2. بدء الرسوم المتحركة
    const circleInterval = setInterval(animateCircle, 100);
    const progressInterval = setInterval(updateProgress, 50); // سرعة المحاكاة

    // 3. تنفيذ التثبيت الفعلي في الخلفية
    try {
        execSync(`pkg install ${pkgName} -y`, { stdio: 'ignore' });
    } catch (e) {
        clearInterval(circleInterval);
        clearInterval(progressInterval);
        circleBox.setContent(`\n${chalk.red('❌ فشل التثبيت!')}\n${chalk.gray(e.message)}`);
        screen.render();
        return;
    }

    // 4. إيقاف المحاكاة وإظهار النجاح
    clearInterval(circleInterval);
    clearInterval(progressInterval);
    progressValue = 100;
    updateProgress();
    
    circleBox.setContent(`\n${chalk.green('✅ تم التثبيت بنجاح!')}`);
    screen.render();

    // 5. الخروج بعد ثانيتين
    setTimeout(() => {
        screen.destroy();
        process.exit(0);
    }, 2000);
}

// بدء العملية
// هنا نفترض أن اسم الحزمة يتم تمريره كوسيط (يمكنك تغييره)
// مثال: pop install poppy
const args = process.argv.slice(2);
if (args[0] === 'install' && args[1]) {
    installPackage(args[1]);
} else {
    // إذا لم يتم تمرير اسم الحزمة، اطلبها بطريقة بسيطة (أو استخدم الشاشة)
    // للتبسيط سنعرض رسالة استخدام
    screen.destroy();
    console.log(chalk.red('الاستخدام: pop install <package_name>'));
}
